# WwiseColab0419
Sesión de Wwise Colaborativa
/* NO incluir los archivos de la carpeta soundbancks: SoundBanksInfo.xml, PluginsInfo.xml,.validationcache, .wsettings.
Si están en Windows, no incluir los folders .cache y .backup*/
